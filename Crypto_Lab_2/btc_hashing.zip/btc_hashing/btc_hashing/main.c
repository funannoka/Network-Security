//
//  main.c
//  btc_hashing
//
//  Created by Ifunanya Nnoka on 12/2/16.
//  Copyright © 2016 Ifunanya Nnoka. All rights reserved.
//

#include <stdio.h>
#include <sys/types.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include<time.h>
#if defined(__APPLE__)
#define COMMON_DIGEST_FOR_OPENSSL
#include <CommonCrypto/CommonDigest.h>
#define SHA1 CC_SHA1
#define SHA512 CC_SHA512
#define MD5 CC_MD5
#define SHA256 CC_SHA256
#else
#include <openssl/sha.h>
#include <openssl/ripemd.h>
#include <openssl/md5.h>
#endif

int main(int argc, const char * argv[]){
   // char previousTx[] = "The Times 03/Jan/2009 Chancellor on brink of second bailout for banks";
    char nextTx[] = "I, Ifunanya Nnoka, and Rahul Dileep Jadhav began hashing, at 11:11AM December 3, 2016";
  //  unsigned char previousHeader[BUFSIZ];
    unsigned char digest[BUFSIZ];
    unsigned char finaldigest[BUFSIZ];
    char *hash;//= (char*)malloc(256);
    char hex_hash[70];
    char *hexPreviousHeader = "15ad44909d7c00d05384e5a613fd6f132f7441a0";
    char prev_next_nonce[BUFSIZ];
    char str_nonce[32];
    clock_t end;
    clock_t start;
    clock_t elapsed_time,total_t;
    double maxNonce = pow(2,70);
    printf("maxNonce: %f\n",maxNonce);
    long double difficulty;
    long double hash_i;
    long long nonce = 1023070763;
    long double target;
    int n;
    long i=1;
    int NMax = 100;
    int NM,num;
    
    //SHA256(previousTx, strlen(previousTx), previousHeader);
   // for (n = 0; n < SHA256_DIGEST_LENGTH; ++n) {
  //      snprintf(&(hexPreviousHeader[n*2]),SHA256_DIGEST_LENGTH*2,"%02x",(unsigned int)previousHeader[n]);
   // }
        printf("Enter number of bits to match\n");
        printf(":::: >>>>  ");
        scanf("%d",&NM);
        //printf("NM: %d\n",NM);
begin:  num = 256 - NM;
        target = pow(2,num);
        printf("Target: %Lf\n",target);
        difficulty = pow(2,NM);
        //srand(time(NULL));
        //nonce = rand();
        start = clock();
    while (0 <= nonce < maxNonce){
        sprintf(str_nonce,"%lld",nonce);
        strcpy(prev_next_nonce,hexPreviousHeader);
        strcat(prev_next_nonce,nextTx);
        strcat(prev_next_nonce,str_nonce);
        SHA256(prev_next_nonce,strlen(prev_next_nonce),digest);
        SHA256(digest,strlen(digest),finaldigest);
        for (n = 0; n < SHA256_DIGEST_LENGTH; ++n){
        snprintf(&(hex_hash[n*2]),SHA256_DIGEST_LENGTH*2,"%02x",(unsigned int)finaldigest[n]);
        }
        asprintf(&hash,"%Lf",(long long)hex_hash);
       // printf("hex_hash: %s\n",hex_hash);
       // printf("hash: %s\n",hash);
        //hash_i = atof(hash);
        sscanf(hash, "%Lf", &hash_i);
       // printf("hash_i: %Lf\n",hash_i);
        free(hash);
        if(hash_i < target)
        {
            end = clock();
            elapsed_time = end-start;
            total_t = ((double)elapsed_time/CLOCKS_PER_SEC);
            printf("\nFor number: %d diffuculty: %Lf",NM,difficulty);
            printf("\nMatching Found: %s",hex_hash);
            printf("\nFor Previous Header: %s",hexPreviousHeader);
            printf("\nFor Next Tx: %s",nextTx);
            printf("\nFor Nonce Value: %lld",nonce);
            printf("\nElapsed Time: %f",elapsed_time);
            printf("\nElapsed Time secs: %f",total_t);
            printf("\nCPU Hash Speed: %f",(nonce/(double)elapsed_time));
            nonce++;
            break;
        }else{
            nonce++;
            if (nonce == maxNonce) {
                printf("\nFailed after %ld tries\n",i);
            }
        }
        i++;
    }
    printf("\n============\n");
    NM = NM + 1;
    if (NM <NMax)
        goto begin;
    return 0;
}

